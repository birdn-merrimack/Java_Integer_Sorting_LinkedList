Natalie Bird
CSC6301 - IntegerLinktedListSorting

Run command:
	java IntegerLinkedListSorting.java


Javadoc command:
	javadoc -private  IntegerLinkedListSorting.java

Code Reuse:

Lines 32, 37, 70, 85, 107:
I use the Java Collections LinkedList<> utility in order to meet the 'linked list' requirement of this project, instead of re-inventing my own linked list code.

Line 34:
In the getList() method of the IntegerLinkedListSorting class in this program, I reused code from https://stackoverflow.com/questions/7120015/scanner-isnt-reading-the-last-int-on-each-line-because-of-my-delimiter , specifically the 'scanner.useDelimiter(",|\\r\\n");' snippet shared by user Jacko85 on August 23, 2011.
I did this as I was struggling to have my Scanner object close, despite calling .close() on it. Originally, I had '.useDelimited(","). Eventually, I realized my Scanner object was not closing because it was awaiting a "," to delimit the 'nextDouble()'. I chose not to include "\\n" because I believe I only
need "\\r" to capture a return (or 'enter') key press in order to advance the Scanner's next() parsing and proceed through the rest of the code in 'getList()'.
	Edit in Version 2.0 : Added "\\n" to the Delimiter.

Line 73:
Instead of coding in a sorting algorithm, I call LinkedList<>.sort(), some documentation can be found here: https://www.w3schools.com/java/ref_linkedlist_sort.asp . By using "null" as the Comparator, .sort() defaults to sorting from least to greatest (or alphabetically).

Line 89:
I use the Java Collections ListIterator<> utility instead of using a do-while or for loop to iterate through the LinkedList<> passed in as a parameter to 'printList()'.

