/**
 * CSC6301 - Project 4 - Linked List and Collections Framework
 * 
 * Program prompts user to input a comma-delimited list of integers, sorts the list from least to greatest, and prints out the sorted list.
 * 
 * No AI was used to assist in writing this code. No code was
 * 
 * @author Natalie Bird
 * @version 2.0
 * @since 1.0
*/

// Import Scanner, LinkedList, and ListIterator modules
import java.util.LinkedList;
import java.util.ListIterator;
import java.util.Scanner;


/**
 * Main class of IntegerLinkedListSorting.java
 * Private methods are getList(), sortList(), and printList().
 * 
 */
public class IntegerLinkedListSorting {
    
    /**
     * Uses a Scanner object to receive user input and parse it into a LinkedList of Integers.
     * Catches exceptions when Scanner object runs into an error (e.g. finds a String instead of an Integer) and prints out the exception.
     * Otherwise returns the LinkedList.
     * 
     * @return LinkedList (Integer)
     */
    private static LinkedList<Integer> getList() {
        // Scanner object to take user input: inputScanner. Uses "," as a delimiter until the last value which requires \\r for 'return' (aka Enter key).
        Scanner inputScanner = new Scanner(System.in).useDelimiter(",|\\r\\n");

        // Create a LinkedList<> class object from java.util.LinkedList to contain Integers inputted by user: integerList.
        LinkedList<Integer> integerList = new LinkedList<>();

        // Catch the NumberFormatException error thrown when a String is inputted.
        try {
            // Prompt user to input a list of Integers, delimited by commas.
            System.out.println("Enter a comma-delimited list of Integers without spaces (e.g. 1,5,-7,10,33,-16). When finished, press the 'Enter' key twice:\n") ;
            // Do-While to parse input and add to LinkedList
            do{
                // Capture next value in inputScanner string as a Double, convert to Integer, add it to integerList
                integerList.add((int) inputScanner.nextDouble());
            // Do the above operation so long as the Scanner object (inputScanner) has a Double followed by "," or "\r"
            } while (inputScanner.hasNextDouble());
            inputScanner.close();
   
        // Catch NumberFormatException, etc.
        } catch (Exception ohno) {
            System.out.println("Caught Error: " + ohno + "\nClosing inputScanner ... ");
            // Close the Scanner object
            inputScanner.close();
        } 

        // Return the LinkedList 'integerList'
        return integerList;

    }

    /**
     * Accepts a LinkedList of Integers and sorts it from least to greatest.
     * Returns sorted LinkedList.
     * 
     * @param listToSort LinkedList (Integer)
     * @return LinkedList (Integer)
     */
    private static LinkedList<Integer> sortList(LinkedList<Integer> listToSort) {
        // If listToSort has only 1 value, just return it. If not, call LinkedList<>.sort(). 'c:null' defaults the sort mechanism to using ascending numberical order.
        if (listToSort.size() > 1) {
            listToSort.sort(null);
        }
        // Return the now-sorted 'listTotSort'
        return listToSort;
    }

    /**
     * Accepts a LinkedList of Integers and uses ListIterator to iterate through and print out the values.
     * Formats as a comma-delimited string.
     * 
     * @param listToPrint LinkedList (Integer)
     */
    private static void printList(LinkedList<Integer> listToPrint) {
        // Create preliminary output string: output
        String output = "Sorted List:\n";
        // Create ListIterator for integerList: it
        ListIterator<Integer> it = listToPrint.listIterator();
        while (it.hasNext()) {
            output += it.next() + ",";
        }
        // Remove the last "," by taking a substring of 'ouput' up to the penultimate character
        output = output.substring(0, output.length()-1);
        // Print 'output'
        System.out.println(output);
    }

    /**
     * Main method of program.
     * - Calls 'getList()' which prompts for and receives a user-inputted list of numbers. Stores return as LinkedList (Integer): inputList.
     * - Calls 'printList()' on 'sortList(inputList)' to print out the sorted LinkedList. 'sortList()' very simply sorts the LinkedList. 'printList()' iterates through the LinkedList and prints out the values in a formatted String.
     * 
     * @param args Required for public static void main to run
     */
    public static void main(String[] args) {
        LinkedList<Integer> inputList = getList();
        printList(sortList(inputList));
    }   
}